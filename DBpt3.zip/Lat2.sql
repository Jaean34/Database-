-- use sales;
CREATE TABLE customers (
CustomerID int,
CustomerName varchar(40),
ContactName varchar(40),
Address varchar(50),
City varchar(25),
PostalCode varchar(10)
Country varchar(20)
)

SELECT * FROM customers;