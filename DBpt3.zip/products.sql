CREATE TABLE Products (
  ProductID INT PRIMARY KEY,
  ProductName VARCHAR(100),
  SupplierID INT,
  CategoryID INT,
  Unit VARCHAR(100),
  Price DECIMAL(10,2)
);