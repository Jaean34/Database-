select city, count( *) as jumlahCustomer from customers
group by city